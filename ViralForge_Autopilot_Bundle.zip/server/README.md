# ViralForge production backend blueprint

The real autopilot should run server-side:
1. Generate and score concepts.
2. Create scripts and shot lists.
3. Call permitted AI media providers.
4. Generate narration.
5. Render 9:16 videos.
6. Run quality/safety checks.
7. Store finished assets.
8. Schedule/publish through official APIs where permitted.
9. Collect analytics.
10. Feed performance back into the scoring system.

Keep all API keys in server-side secrets. Never put them in index.html or other public files.
