# ViralForge AI Studio
Mobile-first autopilot dashboard.

The included frontend works on GitHub Pages and simulates the production queue. GitHub Pages is static hosting, so a real autonomous AI/video pipeline needs a secure backend/worker plus service accounts and server-side secrets.

Do not put private API keys in the website. Use official APIs/OAuth for any publishing integration and follow platform rules. Revenue is not guaranteed.
